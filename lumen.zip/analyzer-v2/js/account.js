// account.js — 설정 보조 (app.js의 restorePrefs/bindModals와 연동)
// 대부분의 설정 로직은 app.js에 통합되어 있습니다.
// 이 파일은 향후 계정/프로필 확장을 위한 자리입니다.
const Account = {
  // reserved for future use
};
