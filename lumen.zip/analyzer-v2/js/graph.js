// graph.js
const Graph = {
  bar: null, pie: null, weekly: null,
  render(r) {
    const kws = r.keywords || [];
    if (!kws.length) return;
    const labels = kws.map(k => k.word);
    const data   = kws.map(k => k.importance);
    const accent  = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00d4ff';
    const palette = [accent,'#a855f7','#22c55e','#f97316','#f43f5e','#eab308','#06b6d4','#ec4899'];
    const dark = document.documentElement.getAttribute('data-theme') !== 'light';
    Chart.defaults.color = dark ? '#9090b0' : '#505070';
    const grid = dark ? '#ffffff10' : '#00000010';

    const barCtx = document.getElementById('barChart')?.getContext('2d');
    if (barCtx) {
      if (this.bar) this.bar.destroy();
      this.bar = new Chart(barCtx, {
        type: 'bar',
        data: { labels, datasets: [{ data, backgroundColor: palette.map(c => c + 'aa'), borderColor: palette, borderWidth: 1.5, borderRadius: 6 }] },
        options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 5, grid: { color: grid } }, x: { grid: { display: false } } } }
      });
    }
    const pieCtx = document.getElementById('pieChart')?.getContext('2d');
    if (pieCtx) {
      if (this.pie) this.pie.destroy();
      this.pie = new Chart(pieCtx, {
        type: 'doughnut',
        data: { labels, datasets: [{ data, backgroundColor: palette.map(c => c + 'cc'), borderColor: palette, borderWidth: 1.5, hoverOffset: 8 }] },
        options: { responsive: true, plugins: { legend: { position: 'right', labels: { font: { size: 11 } } } } }
      });
    }
  },
  renderWeekly() {
    const ctx = document.getElementById('weeklyChart')?.getContext('2d');
    if (!ctx) return;
    const data = S.weekly();
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00d4ff';
    const dark = document.documentElement.getAttribute('data-theme') !== 'light';
    const grid = dark ? '#ffffff10' : '#00000010';
    if (this.weekly) this.weekly.destroy();
    this.weekly = new Chart(ctx, {
      type: 'bar',
      data: { labels: ['일','월','화','수','목','금','토'], datasets: [{ data, backgroundColor: data.map((_, i) => i === new Date().getDay() ? accent + 'cc' : accent + '30'), borderColor: accent, borderWidth: 1.5, borderRadius: 4 }] },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: grid } }, x: { grid: { display: false } } } }
    });
  }
};
