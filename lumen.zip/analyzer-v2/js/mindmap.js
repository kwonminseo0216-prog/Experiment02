// mindmap.js
const Mindmap = {
  scale: 1,
  render(r) {
    const nodes = r.mindmapNodes; if (!nodes) return;
    const svg = document.getElementById('mindmapSvg');
    svg.innerHTML = '';
    const W = svg.clientWidth || 760, H = 520;
    const cx = W / 2, cy = H / 2;
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00d4ff';
    const palette = [accent, '#a855f7', '#22c55e', '#f97316', '#f43f5e', '#eab308', '#06b6d4', '#ec4899'];
    const branches = nodes.branches || [];

    this.drawCenter(svg, cx, cy, nodes.center, accent);

    const step = (2 * Math.PI) / branches.length;
    branches.forEach((br, i) => {
      const angle = i * step - Math.PI / 2;
      const bx = cx + 170 * Math.cos(angle), by = cy + 170 * Math.sin(angle);
      const col = palette[i % palette.length];
      this.line(svg, cx, cy, bx, by, col, 2);
      this.node(svg, bx, by, br.label, col, 13);

      (br.children || []).forEach((ch, j) => {
        const n = br.children.length;
        const spread = Math.PI / 3.5;
        const la = angle + (j - (n - 1) / 2) * (spread / Math.max(n - 1, 1));
        const lx = bx + 90 * Math.cos(la), ly = by + 90 * Math.sin(la);
        this.line(svg, bx, by, lx, ly, col + '60', 1.5);
        this.leafNode(svg, lx, ly, ch, col, 11);
      });
    });

    this.bindControls(svg, W, H);
  },

  drawCenter(svg, x, y, label, color) {
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    const r = 52;
    const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    c.setAttribute('cx', x); c.setAttribute('cy', y); c.setAttribute('r', r);
    c.setAttribute('fill', color + '18'); c.setAttribute('stroke', color); c.setAttribute('stroke-width', '2');
    c.setAttribute('filter', `drop-shadow(0 0 12px ${color}80)`);
    const t = this.mkText(x, y, label || '', color, 13, true);
    g.appendChild(c); g.appendChild(t);
    svg.appendChild(g);
  },

  node(svg, x, y, label, color, fs) {
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    const disp = label && label.length > 9 ? label.slice(0, 9) + '…' : (label || '');
    const w = Math.max(disp.length * fs * 0.62 + 16, 52), h = fs + 14;
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', x - w/2); rect.setAttribute('y', y - h/2);
    rect.setAttribute('width', w); rect.setAttribute('height', h); rect.setAttribute('rx', h/2);
    rect.setAttribute('fill', color + '20'); rect.setAttribute('stroke', color); rect.setAttribute('stroke-width', '1.5');
    rect.setAttribute('filter', `drop-shadow(0 0 6px ${color}50)`);
    g.appendChild(rect); g.appendChild(this.mkText(x, y, disp, color, fs));
    g.title = label;
    svg.appendChild(g);
  },

  leafNode(svg, x, y, label, color, fs) {
    const disp = label && label.length > 8 ? label.slice(0, 8) + '…' : (label || '');
    const w = Math.max(disp.length * fs * 0.6 + 10, 44), h = fs + 10;
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', x - w/2); rect.setAttribute('y', y - h/2);
    rect.setAttribute('width', w); rect.setAttribute('height', h); rect.setAttribute('rx', h/2);
    rect.setAttribute('fill', color + '0d'); rect.setAttribute('stroke', color + '50'); rect.setAttribute('stroke-width', '1');
    svg.appendChild(rect);
    svg.appendChild(this.mkText(x, y, disp, color + 'cc', fs));
  },

  line(svg, x1, y1, x2, y2, stroke, w) {
    const l = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    ['x1','y1','x2','y2'].forEach((a, i) => l.setAttribute(a, [x1,y1,x2,y2][i]));
    l.setAttribute('stroke', stroke); l.setAttribute('stroke-width', w); l.setAttribute('stroke-linecap', 'round');
    svg.appendChild(l);
  },

  mkText(x, y, text, fill, fs, bold) {
    const t = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    t.setAttribute('x', x); t.setAttribute('y', y + fs * 0.38);
    t.setAttribute('text-anchor', 'middle'); t.setAttribute('fill', fill);
    t.setAttribute('font-size', fs); t.setAttribute('font-family', 'Pretendard, sans-serif');
    if (bold) t.setAttribute('font-weight', '700');
    t.textContent = text;
    return t;
  },

  bindControls(svg, W, H) {
    let s = 1;
    const vb = () => { const vw = W/s, vh = H/s; svg.setAttribute('viewBox', `${(W-vw)/2} ${(H-vh)/2} ${vw} ${vh}`); };
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    document.getElementById('mmZoomIn')?.addEventListener('click',  () => { s = Math.min(s + .25, 4); vb(); });
    document.getElementById('mmZoomOut')?.addEventListener('click', () => { s = Math.max(s - .25, .4); vb(); });
    document.getElementById('mmReset')?.addEventListener('click',   () => { s = 1; svg.setAttribute('viewBox', `0 0 ${W} ${H}`); });
  }
};
