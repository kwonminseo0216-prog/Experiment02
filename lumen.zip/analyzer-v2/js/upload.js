// upload.js — PDF/DOCX/TXT/이미지 업로드, 드래그 앤 드롭
const Upload = {
  init() {
    const dz = document.getElementById('dropZone'), fi = document.getElementById('fileInput');
    if (!dz) return;
    dz.addEventListener('click', () => fi.click());
    fi.addEventListener('change', e => this.handle(e.target.files));
    dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('over'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('over'));
    dz.addEventListener('drop', e => { e.preventDefault(); dz.classList.remove('over'); this.handle(e.dataTransfer.files); });
  },

  async handle(files) {
    if (!files?.length) return;
    const file = files[0];
    const ext = file.name.split('.').pop().toLowerCase();
    const status = document.getElementById('uploadStatus');
    status.textContent = `처리 중: ${file.name}`;
    status.classList.remove('hidden');

    try {
      let text = '';
      if (ext === 'txt') text = await this.readTXT(file);
      else if (ext === 'pdf') text = await this.readPDF(file);
      else if (ext === 'docx') text = await this.readDOCX(file);
      else if (['png','jpg','jpeg'].includes(ext)) { await OCR.processFile(file); status.textContent = `이미지 OCR 완료: ${file.name}`; return; }
      else throw new Error('지원하지 않는 파일 형식입니다.');

      if (text.trim()) {
        document.getElementById('inputText').value = text.trim();
        S.saveInput(text.trim());
        App.updateCount(text.trim());
        App.detectLang(text.trim());
        status.textContent = `✓ 로드 완료: ${file.name} (${text.length}자)`;
        App.toast('파일 내용이 입력창에 추가되었습니다.', 'ok');
      }
    } catch (err) {
      status.textContent = `✕ 오류: ${err.message}`;
      App.toast(err.message, 'err');
    }
  },

  readTXT(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = e => res(e.target.result);
      r.onerror = () => rej(new Error('파일 읽기 실패'));
      r.readAsText(file, 'UTF-8');
    });
  },

  readPDF(file) {
    return new Promise((res, rej) => {
      if (typeof pdfjsLib !== 'undefined') {
        const r = new FileReader();
        r.onload = async e => {
          try {
            const pdf = await pdfjsLib.getDocument({ data: e.target.result }).promise;
            let text = '';
            for (let i = 1; i <= pdf.numPages; i++) {
              const page = await pdf.getPage(i);
              const content = await page.getTextContent();
              text += content.items.map(it => it.str).join(' ') + '\n';
            }
            res(text);
          } catch (err) { rej(err); }
        };
        r.readAsArrayBuffer(file);
      } else {
        const r = new FileReader();
        r.onload = e => {
          const extracted = e.target.result.replace(/[^\x20-\x7E\uAC00-\uD7A3\u3040-\u30FF]/g, ' ').replace(/\s+/g, ' ').trim();
          if (extracted.length > 50) res(extracted);
          else rej(new Error('PDF 텍스트 추출 실패. TXT로 변환해 업로드해주세요.'));
        };
        r.readAsText(file);
      }
    });
  },

  readDOCX(file) {
    return new Promise((res, rej) => {
      if (typeof mammoth !== 'undefined') {
        const r = new FileReader();
        r.onload = async e => {
          try { const result = await mammoth.extractRawText({ arrayBuffer: e.target.result }); res(result.value); }
          catch { rej(new Error('DOCX 읽기 실패')); }
        };
        r.readAsArrayBuffer(file);
      } else rej(new Error('DOCX 라이브러리 미로드. TXT로 변환해주세요.'));
    });
  }
};
