// aiTeacher.js — AI 선생님 채팅 (Claude API)
const AITeacher = {
  history: [],

  init() {
    document.getElementById('aiSend')?.addEventListener('click', () => this.ask());
    document.getElementById('aiQ')?.addEventListener('keydown', e => { if (e.key === 'Enter') this.ask(); });
    document.querySelectorAll('.chip').forEach(btn => {
      btn.addEventListener('click', () => { document.getElementById('aiQ').value = btn.dataset.q; this.ask(); });
    });
  },

  async ask() {
    const input = document.getElementById('aiQ');
    const q = input.value.trim();
    if (!q) return;
    input.value = '';
    this.append('user', q);

    const ctx = currentResult
      ? `현재 분석된 지문 정보:\n중심내용: ${currentResult.mainTopic || ''}\n요약: ${currentResult.summary || ''}\n키워드: ${(currentResult.keywords||[]).map(k=>k.word).join(', ')}`
      : '아직 분석된 지문이 없습니다.';

    const system = `당신은 친절하고 유능한 국어/영어 AI 선생님입니다. 학생의 질문에 명확하고 쉽게, 300자 이내로 답하세요.\n${ctx}`;

    this.typing(true);

    try {
      const msgs = [...this.history.slice(-6), { role: 'user', content: q }];
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 600, system, messages: msgs })
      });
      if (!res.ok) throw new Error('API 오류');
      const data = await res.json();
      const answer = data.content?.map(b => b.text || '').join('') || '답변을 가져올 수 없습니다.';

      this.typing(false);
      this.append('ai', answer);
      this.history.push({ role: 'user', content: q }, { role: 'assistant', content: answer });
      if (this.history.length > 20) this.history = this.history.slice(-20);
    } catch (e) {
      this.typing(false);
      this.append('ai', '오류가 발생했습니다: ' + e.message);
    }
  },

  append(role, text) {
    const h = document.getElementById('chatHistory');
    if (!h) return;
    const div = document.createElement('div');
    div.className = `chat-msg ${role}`;
    div.innerHTML = `<div class="chat-avatar">${role === 'ai' ? '◈' : '●'}</div><div class="chat-bubble">${text.replace(/\n/g,'<br>')}</div>`;
    h.appendChild(div); h.scrollTop = h.scrollHeight;
  },

  typing(on) {
    if (on) {
      const h = document.getElementById('chatHistory');
      const div = document.createElement('div');
      div.className = 'chat-msg ai'; div.id = 'aiTyping';
      div.innerHTML = `<div class="chat-avatar">◈</div><div class="chat-bubble" style="color:var(--text-3)">생각하는 중...</div>`;
      h.appendChild(div); h.scrollTop = h.scrollHeight;
    } else {
      document.getElementById('aiTyping')?.remove();
    }
  }
};
