// highlight.js — 중요 문장 형광펜, 시험 포인트
const Highlight = {
  render(r, originalText) {
    const container = document.getElementById('hlContent');
    if (!container) return;

    const important = r.importantSentences || [];
    const examPoints = r.examPoints || [];

    const set1 = new Set(important.filter(s => s.importance === 3).map(s => s.sentence));
    const set2 = new Set(important.filter(s => s.importance === 2).map(s => s.sentence));
    const set3 = new Set(important.filter(s => s.importance === 1).map(s => s.sentence));

    const sentences = originalText.split(/(?<=[.!?。])\s+|(?<=。)/g).filter(s => s.trim());

    let html = `
      <div class="hl-wrap">
        <div class="hl-legend">
          <div class="hl-legend-item"><span class="hl-swatch" style="background:var(--accent)"></span>핵심 문장</div>
          <div class="hl-legend-item"><span class="hl-swatch" style="background:var(--purple)"></span>중요 문장</div>
          <div class="hl-legend-item"><span class="hl-swatch" style="background:var(--green)"></span>참고 문장</div>
        </div>
        <div class="hl-text">
    `;

    sentences.forEach((s, i) => {
      const t = s.trim();
      if (!t) return;
      const m = (arr) => [...arr].some(x => t.includes(x.substring(0, Math.min(x.length, 15))));
      let cls = '', title = '';
      if (m(set1)) { cls = 'hl-s hl-1'; title = '핵심 문장'; }
      else if (m(set2)) { cls = 'hl-s hl-2'; title = '중요 문장'; }
      else if (m(set3)) { cls = 'hl-s hl-3'; title = '참고 문장'; }

      html += cls
        ? `<span class="${cls}" title="${title}" data-idx="${i}">${t}</span> `
        : `<span>${t}</span> `;
    });

    html += `</div></div>`;

    if (examPoints.length) {
      html += `<div class="hl-wrap" style="margin-top:1rem">
        <div class="card-head" style="border:none;padding:0 0 .85rem 0;color:var(--accent)"><span class="dot" style="background:var(--accent)"></span>시험 출제 예상 포인트</div>`;
      examPoints.forEach(ep => {
        html += `
          <div style="padding:.75rem 1rem;border-radius:8px;border:1px solid var(--border-2);background:var(--bg-2);margin-bottom:.5rem">
            <div style="font-size:.7rem;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:.06em;margin-bottom:.3rem">${ep.type}</div>
            <div style="font-size:.86rem;font-weight:600;margin-bottom:.3rem">${ep.point}</div>
            <div style="font-size:.78rem;color:var(--text-3)">💡 ${ep.tip}</div>
          </div>`;
      });
      html += `</div>`;
    }

    container.innerHTML = html;

    container.querySelectorAll('.hl-s').forEach(el => {
      el.addEventListener('click', () => {
        const idx = +el.dataset.idx;
        const data = important[Math.min(idx, important.length - 1)];
        App.toast(data?.reason || '중요 문장입니다.', '');
      });
    });
  }
};
