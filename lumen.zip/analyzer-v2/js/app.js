// app.js — main controller
let currentResult = null;

const App = {
  init() {
    this.restorePrefs();
    this.bindTabs();
    this.bindTopbar();
    this.bindInput();
    this.bindAnalyze();
    this.bindCompare();
    this.bindModals();
    Upload.init();
    OCR.init();
    TTS.init();
    Timer.init();
    History.init();
    Export.init();
  },

  restorePrefs() {
    // Dark/light
    const dark = S.dark();
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');

    // Font size
    document.documentElement.style.setProperty('--font-size', S.fontSize() + 'px');

    // Accent
    this.setAccent(S.accent());

    // Inputs
    const txt = S.input();
    if (txt) { document.getElementById('inputText').value = txt; this.updateCount(txt); this.detectLang(txt); }

    document.getElementById('gradeSelect').value = S.grade();
    document.getElementById('gradeSelect').addEventListener('change', e => S.saveGrade(e.target.value));
  },

  bindTabs() {
    document.querySelectorAll('.tab').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById('panel-' + btn.dataset.tab)?.classList.add('active');
        if (btn.dataset.tab === 'stats') Stats.refresh();
      });
    });
  },

  bindTopbar() {
    document.getElementById('themeBtn')?.addEventListener('click', () => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
      S.saveDark(!isDark);
    });

    document.getElementById('timerBtn')?.addEventListener('click', () => {
      document.getElementById('timerWidget')?.classList.toggle('hidden');
    });

    document.getElementById('historyBtn')?.addEventListener('click', () => {
      document.querySelector('[data-tab="history"]')?.click();
    });

    document.getElementById('compareBtn')?.addEventListener('click', () => {
      document.getElementById('compareSection')?.classList.toggle('hidden');
    });

    document.getElementById('settingsBtn')?.addEventListener('click', () => {
      document.getElementById('settingsModal')?.classList.remove('hidden');
    });
  },

  bindInput() {
    const ta = document.getElementById('inputText');
    ta.addEventListener('input', e => {
      S.saveInput(e.target.value);
      this.updateCount(e.target.value);
      this.detectLang(e.target.value);
    });

    document.getElementById('clearBtn')?.addEventListener('click', () => {
      ta.value = ''; S.saveInput('');
      this.updateCount('');
      document.getElementById('langBadge').textContent = '자동';
    });
  },

  updateCount(txt) {
    document.getElementById('charCount').textContent = txt.length.toLocaleString() + '자';
  },

  detectLang(txt) {
    const badge = document.getElementById('langBadge');
    if (!badge || !txt.trim()) { badge && (badge.textContent = '자동'); return; }
    const ko = (txt.match(/[\uAC00-\uD7A3]/g) || []).length;
    const en = (txt.match(/[a-zA-Z]/g) || []).length;
    badge.textContent = ko > en ? '🇰🇷 국어' : en > ko ? '🇺🇸 영어' : '자동';
  },

  detectLangOf(txt) {
    const ko = (txt.match(/[\uAC00-\uD7A3]/g) || []).length;
    const en = (txt.match(/[a-zA-Z]/g) || []).length;
    return ko >= en ? 'ko' : 'en';
  },

  bindAnalyze() {
    document.getElementById('analyzeBtn')?.addEventListener('click', () => this.run());
  },

  async run() {
    const text = document.getElementById('inputText').value.trim();
    const grade = document.getElementById('gradeSelect').value;
    if (!text || text.length < 30) { this.toast('지문을 30자 이상 입력해주세요.', 'err'); return; }

    this.showLoading();

    try {
      const result = await Analysis.analyze(text, grade);
      currentResult = result;
      S.saveResult(result);
      this.hideLoading();
      this.showResults(result, text);
      History.add(result, text, grade);
      this.toast('분석 완료!', 'ok');
    } catch (e) {
      this.hideLoading();
      this.toast('오류: ' + (e.message || '분석 실패'), 'err');
      console.error(e);
    }
  },

  showResults(result, text) {
    document.getElementById('hero')?.classList.add('hidden');
    const ra = document.getElementById('resultArea');
    ra.classList.remove('hidden');
    Analysis.render(result);
    Mindmap.render(result);
    Graph.render(result);
    WordCloud.render(result);
    Highlight.render(result, text);
    Questions.render(result);
    Planner.render(result);
    document.querySelector('[data-tab="summary"]')?.click();
  },

  bindCompare() {
    document.getElementById('compareRunBtn')?.addEventListener('click', () => Compare.run());
  },

  bindModals() {
    document.querySelectorAll('.modal-close').forEach(btn => {
      btn.addEventListener('click', () => {
        document.getElementById(btn.dataset.close)?.classList.add('hidden');
      });
    });
    // Settings
    document.getElementById('fontRange')?.addEventListener('input', e => {
      const v = +e.target.value;
      document.documentElement.style.setProperty('--font-size', v + 'px');
      document.getElementById('fontVal').textContent = v + 'px';
      S.saveFontSize(v);
    });
    document.getElementById('fontRange').value = S.fontSize();
    document.getElementById('fontVal').textContent = S.fontSize() + 'px';

    document.querySelectorAll('.swatch').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.swatch').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.setAccent(btn.dataset.color);
        S.saveAccent(btn.dataset.color);
      });
      if (btn.dataset.color === S.accent()) btn.classList.add('active');
    });
  },

  setAccent(color) {
    document.documentElement.style.setProperty('--accent', color);
    // derive dim & glow
    document.documentElement.style.setProperty('--accent-dim', color + '28');
    document.documentElement.style.setProperty('--accent-glow', color + '55');
  },

  showLoading() {
    document.getElementById('loadingScreen').classList.remove('hidden');
    // Animate steps
    const steps = document.querySelectorAll('.loading-steps .step');
    steps.forEach(s => s.classList.remove('active'));
    let i = 0;
    this._stepInterval = setInterval(() => {
      steps.forEach(s => s.classList.remove('active'));
      if (steps[i]) steps[i].classList.add('active');
      i = (i + 1) % steps.length;
    }, 900);
  },

  hideLoading() {
    document.getElementById('loadingScreen').classList.add('hidden');
    clearInterval(this._stepInterval);
  },

  toast(msg, type = '') {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.className = 'toast' + (type ? ' ' + type : '');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => { t.className = 'toast hidden'; }, 3000);
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());
