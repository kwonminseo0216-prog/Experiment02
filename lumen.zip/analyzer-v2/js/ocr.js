// ocr.js — 이미지 OCR (Tesseract.js, API Key 불필요)
const OCR = {
  init() {
    // Lazy-load Tesseract.js only when needed
  },

  async loadTesseract() {
    if (typeof Tesseract !== 'undefined') return;
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
      script.onload = resolve;
      script.onerror = () => reject(new Error('OCR 엔진 로드 실패'));
      document.head.appendChild(script);
    });
  },

  async processFile(file) {
    App.showLoading();
    document.getElementById('loadingText').textContent = 'OCR 엔진 준비 중...';
    const status = document.getElementById('uploadStatus');

    try {
      await this.loadTesseract();
      const text = await this.recognize(file);
      if (text.trim().length > 5) {
        document.getElementById('inputText').value = text.trim();
        S.saveInput(text.trim());
        App.updateCount(text.trim());
        App.detectLang(text.trim());
        if (status) status.textContent = `✓ OCR 완료: ${text.length}자 인식`;
        App.toast('이미지에서 텍스트를 인식했습니다.', 'ok');
      } else {
        throw new Error('텍스트를 인식할 수 없습니다. 더 선명한 이미지를 사용해보세요.');
      }
    } catch (err) {
      if (status) status.textContent = `✕ OCR 실패: ${err.message}`;
      App.toast('OCR 실패: ' + err.message, 'err');
    } finally {
      App.hideLoading();
    }
  },

  recognize(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async e => {
        const img = new Image();
        img.onload = async () => {
          const canvas = document.createElement('canvas');
          const scale = Math.min(1.5, 2200 / Math.max(img.width, img.height));
          canvas.width = img.width * scale;
          canvas.height = img.height * scale;
          const ctx = canvas.getContext('2d');
          ctx.fillStyle = '#fff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

          try {
            const result = await Tesseract.recognize(canvas, 'kor+eng', {
              logger: m => {
                if (m.status === 'recognizing text') {
                  document.getElementById('loadingText').textContent = `텍스트 인식 중... ${Math.round(m.progress * 100)}%`;
                } else if (m.status) {
                  document.getElementById('loadingText').textContent = this.statusLabel(m.status);
                }
              }
            });
            resolve(result.data.text);
          } catch (err) { reject(new Error('OCR 처리 중 오류가 발생했습니다.')); }
        };
        img.onerror = () => reject(new Error('이미지를 불러올 수 없습니다.'));
        img.src = e.target.result;
      };
      reader.onerror = () => reject(new Error('파일 읽기 실패'));
      reader.readAsDataURL(file);
    });
  },

  statusLabel(status) {
    const map = {
      'loading tesseract core': '엔진 로딩 중...',
      'initializing tesseract': '초기화 중...',
      'loading language traineddata': '언어 데이터 로딩 중...',
      'initializing api': 'API 초기화 중...',
    };
    return map[status] || status;
  }
};
