// question.js — 객관식, OX, 서술형, 빈칸, 순서 배열
const Questions = {
  render(r) {
    const c = document.getElementById('qContent');
    if (!c) return;
    const q = r.questions || {};
    let html = '';

    if (q.multiple?.length) {
      html += `<div class="q-section"><div class="q-type-title">객관식 문제</div>`;
      q.multiple.forEach((item, i) => {
        html += `<div class="q-item">
          <div class="q-text"><span class="q-num">${i+1}.</span>${item.question}</div>
          <ul class="opt-list">`;
        item.options.forEach((opt, j) => {
          html += `<li class="opt" data-mcq="${i}" data-idx="${j}" data-answer="${item.answer}" onclick="Grading.mcq(this)">${opt}</li>`;
        });
        html += `</ul><div class="exp-box" id="exp-mcq-${i}">💡 ${item.explanation || ''}</div></div>`;
      });
      html += `</div>`;
    }

    if (q.ox?.length) {
      html += `<div class="q-section"><div class="q-type-title">OX 문제</div>`;
      q.ox.forEach((item, i) => {
        html += `<div class="q-item" id="ox-${i}">
          <div class="q-text"><span class="q-num">${i+1}.</span>${item.statement}</div>
          <div class="ox-row">
            <button class="ox-btn o" data-ox="${i}" data-answer="${item.answer}" onclick="Grading.ox(this,true)">O</button>
            <button class="ox-btn x" data-ox="${i}" data-answer="${item.answer}" onclick="Grading.ox(this,false)">X</button>
          </div>
          <div class="exp-box" id="exp-ox-${i}">💡 ${item.explanation || ''}</div>
        </div>`;
      });
      html += `</div>`;
    }

    if (q.ordering) {
      const ans = q.ordering.answer.map(i => String.fromCharCode(65 + i)).join(' → ');
      html += `<div class="q-section"><div class="q-type-title">순서 배열</div>
        <div class="q-item">
          <div class="q-text">${q.ordering.question}</div>
          <div style="display:flex;flex-direction:column;gap:.4rem;margin:.5rem 0">
            ${q.ordering.sentences.map((s, i) => `<div class="opt" style="cursor:default;border-left:3px solid var(--accent)"><strong style="color:var(--accent)">${String.fromCharCode(65+i)}.</strong> ${s}</div>`).join('')}
          </div>
          <button class="ghost-btn" onclick="this.nextElementSibling.style.display='block';this.style.display='none'">정답 보기</button>
          <div class="exp-box" style="display:none">정답: ${ans}<br>💡 ${q.ordering.explanation || ''}</div>
        </div></div>`;
    }

    if (q.shortAnswer?.length) {
      html += `<div class="q-section"><div class="q-type-title">서술형 문제</div>`;
      q.shortAnswer.forEach((item, i) => {
        html += `<div class="q-item">
          <div class="q-text"><span class="q-num">${i+1}.</span>${item.question}</div>
          <textarea class="field-textarea short" placeholder="답을 작성하세요..." style="margin:.5rem 0"></textarea>
          <button class="ghost-btn" onclick="this.nextElementSibling.style.display='block';this.style.display='none'">예시 답안 보기</button>
          <div class="exp-box" style="display:none"><strong>예시 답안:</strong> ${item.sampleAnswer}<br><strong>채점 포인트:</strong> ${item.point}</div>
        </div>`;
      });
      html += `</div>`;
    }

    html += `<div class="grade-all-row"><button class="cta-btn" style="max-width:220px" onclick="Grading.gradeAll()">전체 채점하기</button></div>`;
    c.innerHTML = html;
  }
};
