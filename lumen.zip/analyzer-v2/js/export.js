// export.js — TXT, Markdown, PDF, 복사
const Export = {
  init() {
    document.getElementById('exportTxt')?.addEventListener('click', () => this.txt());
    document.getElementById('exportMd')?.addEventListener('click', () => this.md());
    document.getElementById('exportPdf')?.addEventListener('click', () => { window.print(); App.toast('인쇄 창에서 PDF로 저장하세요.', 'ok'); });
    document.getElementById('copyAll')?.addEventListener('click', () => this.copy());
    document.getElementById('saveBtn')?.addEventListener('click', () => {
      if (currentResult) { History.add(currentResult, document.getElementById('inputText').value, document.getElementById('gradeSelect').value); App.toast('저장되었습니다.', 'ok'); }
      else App.toast('저장할 분석 결과가 없습니다.', 'err');
    });
  },

  extract() {
    if (!currentResult) return '';
    const r = currentResult;
    return [
      `【지문 분석 결과】`, `언어: ${r.language === 'ko' ? '국어' : '영어'} | 학년: ${r.grade || ''}`, '',
      `[요약]\n${r.summary || ''}`, '',
      `[중심 내용]\n${r.mainTopic || ''}`, '',
      `[핵심 메시지]\n${r.coreMessage || ''}`, '',
      `[주요 키워드]\n${(r.keywords || []).map(k => `• ${k.word} (중요도:${k.importance}) - ${k.description}`).join('\n')}`, '',
      `[글의 구조]\n유형: ${r.structure?.type || ''}\n도입: ${r.structure?.intro || ''}\n본론: ${r.structure?.body || ''}\n결론: ${r.structure?.conclusion || ''}`, '',
      `[시험 출제 예상 포인트]\n${(r.examPoints || []).map(e => `• [${e.type}] ${e.point}\n  팁: ${e.tip}`).join('\n')}`,
    ].join('\n');
  },

  txt() {
    const t = this.extract();
    if (!t) return App.toast('분석 결과가 없습니다.', 'err');
    this.dl(new Blob([t], { type: 'text/plain;charset=utf-8' }), '지문분석결과.txt');
    App.toast('TXT 저장 완료', 'ok');
  },

  md() {
    if (!currentResult) return App.toast('분석 결과가 없습니다.', 'err');
    const r = currentResult;
    const md = [
      `# 지문 분석 결과`, `> 언어: **${r.language === 'ko' ? '국어' : '영어'}** | 학년: **${r.grade || ''}**`, '',
      `## 📌 요약`, r.summary || '', '',
      `## 🎯 중심 내용`, r.mainTopic || '', '',
      `## 💡 핵심 메시지`, r.coreMessage || '', '',
      `## 🔑 주요 키워드`, (r.keywords || []).map(k => `- **${k.word}** (중요도 ${k.importance}/5): ${k.description}`).join('\n'), '',
      `## 🏗 글의 구조`, `- **유형**: ${r.structure?.type || ''}`, `- **도입**: ${r.structure?.intro || ''}`, `- **본론**: ${r.structure?.body || ''}`, `- **결론**: ${r.structure?.conclusion || ''}`, '',
      `## 🎯 시험 출제 예상 포인트`, (r.examPoints || []).map(e => `- **[${e.type}]** ${e.point}\n  - 💡 ${e.tip}`).join('\n'),
    ].join('\n');
    this.dl(new Blob([md], { type: 'text/markdown;charset=utf-8' }), '지문분석결과.md');
    App.toast('Markdown 저장 완료', 'ok');
  },

  copy() {
    const t = this.extract();
    if (!t) return App.toast('분석 결과가 없습니다.', 'err');
    navigator.clipboard.writeText(t).then(() => App.toast('복사 완료', 'ok')).catch(() => App.toast('복사 실패', 'err'));
  },

  dl(blob, name) {
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = name; document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
  }
};
