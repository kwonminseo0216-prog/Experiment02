// tts.js — 음성 읽어주기
const TTS = {
  utterance: null, speaking: false, paused: false,

  init() {
    document.getElementById('ttsBtn')?.addEventListener('click', () => this.start());
    document.getElementById('ttsPause')?.addEventListener('click', () => this.pause());
    document.getElementById('ttsStop')?.addEventListener('click', () => this.stop());
    document.getElementById('ttsSpeed')?.addEventListener('input', e => {
      document.getElementById('ttsSpeedVal').textContent = (+e.target.value).toFixed(1) + '×';
      if (this.speaking) { const t = document.getElementById('inputText').value; this.stop(); this.speak(t); }
    });
  },

  start() {
    const text = document.getElementById('inputText').value.trim();
    if (!text) return App.toast('읽을 텍스트가 없습니다.', 'err');
    if (!window.speechSynthesis) return App.toast('이 브라우저는 TTS를 지원하지 않습니다.', 'err');
    this.stop();
    this.speak(text);
  },

  speak(text) {
    const lang = App.detectLangOf(text);
    const speed = +document.getElementById('ttsSpeed').value;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang === 'ko' ? 'ko-KR' : 'en-US';
    u.rate = speed;
    const voices = speechSynthesis.getVoices();
    const v = voices.find(v => v.lang.startsWith(u.lang.split('-')[0]));
    if (v) u.voice = v;

    u.onstart = () => { this.speaking = true; document.getElementById('ttsBar').classList.remove('hidden'); document.getElementById('ttsBtn').textContent = '🔊'; };
    u.onend = () => this.end();
    u.onerror = () => this.end();

    speechSynthesis.speak(u);
    this.utterance = u;
  },

  pause() {
    if (!window.speechSynthesis) return;
    if (this.paused) { speechSynthesis.resume(); this.paused = false; document.getElementById('ttsPause').textContent = '⏸'; }
    else { speechSynthesis.pause(); this.paused = true; document.getElementById('ttsPause').textContent = '▶'; }
  },

  stop() { if (window.speechSynthesis) speechSynthesis.cancel(); this.end(); },

  end() {
    this.speaking = false; this.paused = false;
    document.getElementById('ttsBar')?.classList.add('hidden');
  }
};
