// grading.js — 자동 채점
const Grading = {
  mcqAns: {}, oxAns: {},

  mcq(el) {
    const i = +el.dataset.mcq, sel = +el.dataset.idx, ans = +el.dataset.answer;
    document.querySelectorAll(`.opt[data-mcq="${i}"]`).forEach(o => o.classList.remove('sel'));
    el.classList.add('sel');
    this.mcqAns[i] = { sel, ans };
  },

  ox(el, isO) {
    const i = +el.dataset.ox, ans = el.dataset.answer === 'true';
    el.closest('.q-item').querySelectorAll('.ox-btn').forEach(b => b.classList.remove('sel'));
    el.classList.add('sel');
    this.oxAns[i] = { sel: isO, ans };
  },

  gradeAll() {
    let correct = 0, total = 0;

    document.querySelectorAll('.opt[data-mcq]').forEach(el => {
      const i = +el.dataset.mcq, idx = +el.dataset.idx, ans = +el.dataset.answer;
      const d = this.mcqAns[i];
      if (d) {
        if (idx === ans) el.classList.add('ok');
        else if (idx === d.sel) el.classList.add('ng');
        document.getElementById(`exp-mcq-${i}`)?.style.setProperty('display', 'block');
      }
    });
    Object.values(this.mcqAns).forEach(d => { total++; if (d.sel === d.ans) correct++; });

    Object.entries(this.oxAns).forEach(([i, d]) => {
      total++;
      const ok = d.sel === d.ans;
      if (ok) correct++;
      const item = document.getElementById(`ox-${i}`);
      document.getElementById(`exp-ox-${i}`)?.style.setProperty('display', 'block');
      item?.querySelectorAll('.ox-btn').forEach(btn => {
        const isO = btn.classList.contains('o');
        if (isO === d.ans) btn.classList.add('ok');
        if (isO === d.sel && !ok) btn.classList.add('ng');
      });
    });

    const panel = document.getElementById('scorePanel');
    if (total > 0) {
      const pct = Math.round((correct / total) * 100);
      panel.classList.remove('hidden');
      document.getElementById('scoreTxt').textContent = `${correct} / ${total}점 (${pct}%)`;
      document.getElementById('scoreFill').style.width = pct + '%';
      S.addScore(correct, total);
      App.toast(`채점 완료: ${correct}/${total} (${pct}%)`, pct >= 80 ? 'ok' : '');
    } else {
      App.toast('먼저 문제를 풀어주세요.', 'err');
    }
  }
};
