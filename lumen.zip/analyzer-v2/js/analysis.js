// analysis.js — Claude API 연동 (Anthropic)
const Analysis = {
  async analyze(text, grade) {
    const gradeMap = { middle1:'중학교 1학년', middle2:'중학교 2학년', middle3:'중학교 3학년', high1:'고등학교 1학년', high2:'고등학교 2학년', high3:'고등학교 3학년', csat:'수능' };
    const gradeLabel = gradeMap[grade] || '고등학교 1학년';
    const ko = (text.match(/[\uAC00-\uD7A3]/g) || []).length;
    const en = (text.match(/[a-zA-Z]/g) || []).length;
    const lang = ko >= en ? 'ko' : 'en';

    const prompt = this.buildPrompt(text, gradeLabel, lang);

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 4000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!res.ok) {
      const e = await res.json().catch(() => ({}));
      throw new Error(e?.error?.message || `API 오류 (${res.status})`);
    }

    const data = await res.json();
    const raw = data.content?.map(b => b.text || '').join('') || '';
    return this.parse(raw);
  },

  buildPrompt(text, grade, lang) {
    return `당신은 ${grade} 수준의 국어/영어 지문 분석 전문가입니다.
아래 ${lang === 'ko' ? '국어' : '영어'} 지문을 깊이 분석하고, 순수 JSON만 반환하세요. 마크다운 코드블록이나 설명 없이 JSON 객체만 출력합니다.

지문:
"""
${text}
"""

반환 JSON 구조:
{
  "language": "${lang}",
  "grade": "${grade}",
  "summary": "3~5문장 핵심 요약",
  "mainTopic": "중심 내용 1~2문장",
  "coreMessage": "이 글이 독자에게 전달하려는 핵심 메시지",
  "structure": {
    "type": "글의 유형(논설문/설명문/소설/수필/영어 지문 등)",
    "intro": "도입부 요약",
    "body": "본론 요약",
    "conclusion": "결론 요약"
  },
  "keywords": [
    {"word":"키워드1","importance":5,"description":"설명"},
    {"word":"키워드2","importance":4,"description":"설명"},
    {"word":"키워드3","importance":4,"description":"설명"},
    {"word":"키워드4","importance":3,"description":"설명"},
    {"word":"키워드5","importance":3,"description":"설명"},
    {"word":"키워드6","importance":2,"description":"설명"},
    {"word":"키워드7","importance":2,"description":"설명"},
    {"word":"키워드8","importance":1,"description":"설명"}
  ],
  "flowDiagram": "flowchart LR로 시작하는 Mermaid 흐름도 (원인→과정→결과 또는 주제→근거→결론)",
  "importantSentences": [
    {"sentence":"중요문장1","importance":3,"reason":"이유"},
    {"sentence":"중요문장2","importance":2,"reason":"이유"},
    {"sentence":"중요문장3","importance":1,"reason":"이유"}
  ],
  "examPoints": [
    {"type":"객관식","point":"출제 포인트","tip":"공략법"},
    {"type":"서술형","point":"출제 포인트","tip":"공략법"},
    {"type":"빈칸","point":"출제 포인트","tip":"공략법"}
  ],
  "questions": {
    "multiple": [
      {"question":"문제1","options":["①옵션1","②옵션2","③옵션3","④옵션4","⑤옵션5"],"answer":0,"explanation":"해설"},
      {"question":"문제2","options":["①옵션1","②옵션2","③옵션3","④옵션4","⑤옵션5"],"answer":2,"explanation":"해설"},
      {"question":"문제3","options":["①옵션1","②옵션2","③옵션3","④옵션4","⑤옵션5"],"answer":1,"explanation":"해설"},
      {"question":"내용 일치: 지문과 일치하는 것은?","options":["①옵션1","②옵션2","③옵션3","④옵션4","⑤옵션5"],"answer":3,"explanation":"해설"},
      {"question":"빈칸 추론: 빈칸에 알맞은 것은?","options":["①옵션1","②옵션2","③옵션3","④옵션4","⑤옵션5"],"answer":2,"explanation":"해설"}
    ],
    "ox": [
      {"statement":"진술1","answer":true,"explanation":"해설"},
      {"statement":"진술2","answer":false,"explanation":"해설"},
      {"statement":"진술3","answer":true,"explanation":"해설"}
    ],
    "shortAnswer": [
      {"question":"서술형 문제1","sampleAnswer":"예시 답안","point":"채점 포인트"},
      {"question":"서술형 문제2","sampleAnswer":"예시 답안","point":"채점 포인트"}
    ],
    "ordering": {
      "question":"다음 문장을 순서에 맞게 배열하시오.",
      "sentences":["문장A","문장B","문장C"],
      "answer":[0,1,2],
      "explanation":"해설"
    }
  },
  "mindmapNodes": {
    "center": "중심 주제",
    "branches": [
      {"label":"가지1","children":["세부1","세부2"]},
      {"label":"가지2","children":["세부3","세부4"]},
      {"label":"가지3","children":["세부5","세부6"]},
      {"label":"가지4","children":["세부7"]}
    ]
  },
  "reviewPlan": {
    "title": "복습 계획 제목",
    "day1": "1일 후 복습 내용",
    "day3": "3일 후 복습 내용",
    "day7": "7일 후 복습 내용",
    "day30": "30일 후 복습 내용"
  }
}`;
  },

  parse(raw) {
    try { return JSON.parse(raw.replace(/```json|```/g, '').trim()); }
    catch {
      const m = raw.match(/\{[\s\S]*\}/);
      if (m) try { return JSON.parse(m[0]); } catch {}
      throw new Error('AI 응답 파싱 실패. 다시 시도하세요.');
    }
  },

  render(r) {
    const grid = document.getElementById('summaryGrid');
    if (!grid) return;

    const impLvl = (imp) => imp >= 4 ? 'kw-a' : imp >= 3 ? 'kw-b' : 'kw-c';

    grid.innerHTML = `
      <div class="result-card c-cyan">
        <div class="card-head"><span class="dot"></span>요약</div>
        <div class="card-body">${r.summary || '-'}</div>
      </div>
      <div class="result-card c-purple">
        <div class="card-head"><span class="dot"></span>중심 내용</div>
        <div class="card-body">${r.mainTopic || '-'}</div>
      </div>
      <div class="result-card c-green">
        <div class="card-head"><span class="dot"></span>핵심 메시지</div>
        <div class="card-body">${r.coreMessage || '-'}</div>
      </div>
      <div class="result-card c-orange">
        <div class="card-head"><span class="dot"></span>주요 키워드</div>
        <div class="card-body">
          <div class="kw-list">
            ${(r.keywords || []).map(k => `<span class="kw-tag ${impLvl(k.importance)}" title="${k.description}">${k.word}</span>`).join('')}
          </div>
        </div>
      </div>
      <div class="result-card c-red full">
        <div class="card-head"><span class="dot"></span>글의 구조 · ${r.structure?.type || ''}</div>
        <div class="card-body" style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.85rem">
          <div><strong style="color:var(--text-3);font-size:.72rem;display:block;margin-bottom:.3rem;text-transform:uppercase;letter-spacing:.06em">도입</strong>${r.structure?.intro || '-'}</div>
          <div><strong style="color:var(--text-3);font-size:.72rem;display:block;margin-bottom:.3rem;text-transform:uppercase;letter-spacing:.06em">본론</strong>${r.structure?.body || '-'}</div>
          <div><strong style="color:var(--text-3);font-size:.72rem;display:block;margin-bottom:.3rem;text-transform:uppercase;letter-spacing:.06em">결론</strong>${r.structure?.conclusion || '-'}</div>
        </div>
      </div>
    `;

    // Mermaid flow diagram
    const fd = document.getElementById('flowDiagram');
    if (fd && r.flowDiagram) {
      const diagId = 'mmd-' + Date.now();
      fd.innerHTML = `<div class="card-head" style="margin-bottom:.75rem"><span style="color:var(--accent)">◈</span>&nbsp; 흐름도</div><div class="mermaid" id="${diagId}">${r.flowDiagram}</div>`;
      try {
        mermaid.run({ nodes: [document.getElementById(diagId)] });
      } catch (e) {
        try { mermaid.init(undefined, fd.querySelectorAll('.mermaid')); } catch {}
      }
    }

    // Click keywords for tooltip
    document.querySelectorAll('.kw-tag').forEach(tag => {
      tag.addEventListener('click', () => App.toast(tag.title, ''));
    });
  }
};
