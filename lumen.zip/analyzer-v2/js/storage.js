// storage.js
const S = {
  get(k, d = null) { try { const v = localStorage.getItem(k); return v !== null ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v)        { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  rm(k)            { try { localStorage.removeItem(k); } catch {} },

  input()      { return this.get('lumen_input', ''); },
  saveInput(v) { this.set('lumen_input', v); },

  grade()      { return this.get('lumen_grade', 'high1'); },
  saveGrade(v) { this.set('lumen_grade', v); },

  dark()       { return this.get('lumen_dark', true); },
  saveDark(v)  { this.set('lumen_dark', v); },

  fontSize()       { return this.get('lumen_fs', 14); },
  saveFontSize(v)  { this.set('lumen_fs', v); },

  accent()         { return this.get('lumen_accent', '#00d4ff'); },
  saveAccent(v)    { this.set('lumen_accent', v); },

  result()         { return this.get('lumen_result', null); },
  saveResult(v)    { this.set('lumen_result', v); },

  pomodoro()       { return this.get('lumen_pomo', 0); },
  incPomodoro()    { const n = this.pomodoro() + 1; this.set('lumen_pomo', n); return n; },

  studyMin()       { return this.get('lumen_study', 0); },
  addStudy(m)      { this.set('lumen_study', this.studyMin() + m); },

  weekly()         { return this.get('lumen_weekly', [0,0,0,0,0,0,0]); },
  addWeekly(m)     { const a = this.weekly(); a[new Date().getDay()] += m; this.set('lumen_weekly', a); },

  scores()         { return this.get('lumen_scores', []); },
  addScore(s, t)   { const a = this.scores(); a.push({ s, t, ts: Date.now() }); if (a.length > 200) a.shift(); this.set('lumen_scores', a); },
  avgScore()       { const a = this.scores(); if (!a.length) return 0; return Math.round(a.reduce((x, v) => x + (v.s / v.t) * 100, 0) / a.length); },

  history()        { return this.get('lumen_history', []); },
  saveHistory(v)   { this.set('lumen_history', v); },
};
