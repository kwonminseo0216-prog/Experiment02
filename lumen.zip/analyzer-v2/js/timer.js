// timer.js — 포모도로 타이머
const Timer = {
  interval: null, seconds: 25*60, total: 25*60, running: false, startedAt: null,

  init() {
    document.getElementById('timerStart')?.addEventListener('click', () => this.toggle());
    document.getElementById('timerReset')?.addEventListener('click', () => this.reset());
    document.querySelectorAll('.tmode').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tmode').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.setTime(+btn.dataset.min * 60);
        this.reset();
      });
    });
    this.updateDisplay();
    document.getElementById('pomodoroCount').textContent = S.pomodoro();
  },

  toggle() { this.running ? this.pause() : this.start(); },

  start() {
    this.running = true; this.startedAt = Date.now();
    const btn = document.getElementById('timerStart');
    btn.textContent = '⏸ 정지'; btn.classList.add('running');
    this.interval = setInterval(() => this.tick(), 1000);
  },

  pause() {
    this.running = false; clearInterval(this.interval);
    const btn = document.getElementById('timerStart');
    btn.textContent = '▶ 시작'; btn.classList.remove('running');
    if (this.startedAt) {
      const min = Math.round((Date.now() - this.startedAt) / 60000);
      if (min > 0) { S.addStudy(min); S.addWeekly(min); }
      this.startedAt = null;
    }
  },

  reset() { this.pause(); this.seconds = this.total; this.updateDisplay(); },
  setTime(s) { this.total = s; this.seconds = s; this.updateDisplay(); },

  tick() {
    this.seconds--; this.updateDisplay();
    if (this.seconds <= 0) this.complete();
  },

  complete() {
    this.pause(); this.seconds = 0; this.updateDisplay();
    const min = Math.round(this.total / 60);
    S.addStudy(min); S.addWeekly(min);
    if (this.total === 25*60) document.getElementById('pomodoroCount').textContent = S.incPomodoro();
    if (Notification?.permission === 'granted') new Notification('⏰ 타이머 완료!', { body: '잘했어요! 잠시 쉬어가세요.' });
    App.toast('⏰ 타이머 완료!', 'ok');
    this.beep();
  },

  beep() {
    try {
      const ctx = new AudioContext(), osc = ctx.createOscillator(), gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = 'sine'; osc.frequency.value = 880;
      gain.gain.setValueAtTime(.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + 1);
      osc.start(); osc.stop(ctx.currentTime + 1);
    } catch {}
  },

  updateDisplay() {
    const m = Math.floor(this.seconds/60).toString().padStart(2,'0');
    const s = (this.seconds%60).toString().padStart(2,'0');
    const d = document.getElementById('timerDisplay');
    if (d) {
      d.textContent = `${m}:${s}`;
      d.style.color = this.seconds <= 60 ? 'var(--red)' : this.seconds <= 300 ? 'var(--orange)' : 'var(--accent)';
    }
  }
};
