// studyPlanner.js — 망각곡선 기반 복습 일정
const Planner = {
  render(r) {
    const c = document.getElementById('plannerContent');
    if (!c || !r) return;
    const plan = r.reviewPlan || {};
    const today = new Date();
    const addDays = (n) => { const d = new Date(today); d.setDate(d.getDate()+n); return d.toLocaleDateString('ko-KR', { month:'long', day:'numeric', weekday:'short' }); };

    const schedules = [
      { cls:'rb-1',  days:1,  label:'1일 후 복습',  content: plan.day1  || '핵심 키워드 재확인' },
      { cls:'rb-3',  days:3,  label:'3일 후 복습',  content: plan.day3  || '중심 내용 요약 복습' },
      { cls:'rb-7',  days:7,  label:'7일 후 복습',  content: plan.day7  || '예상 문제 다시 풀기' },
      { cls:'rb-30', days:30, label:'30일 후 복습', content: plan.day30 || '전체 내용 최종 점검' },
    ];

    c.innerHTML = `
      <div class="planner-box">
        <h3>${plan.title || '망각곡선 기반 복습 일정'}</h3>
        <p class="sub">에빙하우스 망각곡선에 따른 최적 복습 타이밍입니다.</p>

        <svg width="100%" height="76" viewBox="0 0 300 76" style="margin-bottom:1.25rem">
          <path d="M 10 8 Q 60 14 100 32 Q 150 50 200 58 Q 250 64 290 66" stroke="#f43f5e55" stroke-width="2" fill="none" stroke-dasharray="4"/>
          <path d="M 10 8 L 40 8 Q 45 22 50 19 L 90 19 Q 95 34 100 31 L 160 31 Q 165 45 170 42 L 240 42 Q 245 52 250 49 L 290 49"
                stroke="var(--accent)" stroke-width="2.2" fill="none"/>
          <circle cx="50" cy="19" r="4" fill="#eab308"/>
          <circle cx="100" cy="31" r="4" fill="var(--accent)"/>
          <circle cx="170" cy="42" r="4" fill="#a855f7"/>
          <circle cx="250" cy="49" r="4" fill="#22c55e"/>
          <text x="148" y="55" font-size="8" fill="#f43f5e">복습 없이</text>
          <text x="2" y="11" font-size="7" fill="#9090b0">기억률 100%</text>
        </svg>

        <div class="review-list">
          ${schedules.map(s => `
            <div class="review-item">
              <div class="review-day">${addDays(s.days)}</div>
              <div class="review-info"><div class="review-label">${s.label}</div><div class="review-desc">${s.content}</div></div>
              <span class="review-badge ${s.cls}">D+${s.days}</span>
            </div>`).join('')}
        </div>

        <div class="planner-tips">
          💡 복습 시 원문을 보지 않고 핵심 키워드부터 떠올려보세요.<br>
          💡 예상 문제를 다시 풀어 약점을 점검하세요.<br>
          💡 이해가 안 되는 부분은 AI 선생님 탭에서 질문하세요.
        </div>
      </div>
    `;

    // Save & schedule lightweight notifications
    const planData = schedules.map(s => ({ date: today.getTime() + s.days*86400000, label: s.label, content: s.content, topic: r.mainTopic || '지문 복습' }));
    S.set('lumen_review_plan', planData);

    if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
    if ('Notification' in window && Notification.permission === 'granted') {
      planData.forEach(p => {
        const delay = p.date - Date.now();
        if (delay > 0 && delay < 86400000) setTimeout(() => new Notification('📚 복습 알림', { body: `${p.topic} — ${p.label}` }), delay);
      });
    }
  }
};
