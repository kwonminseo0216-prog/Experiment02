// wordcloud.js
const WordCloud = {
  render(r) {
    const wrap = document.getElementById('cloudWrap');
    if (!wrap) return;
    wrap.innerHTML = '';
    const kws = r.keywords || [];
    if (!kws.length) return;
    const W = wrap.offsetWidth || 640, H = 420;
    wrap.style.height = H + 'px';
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00d4ff';
    const palette = [accent, '#a855f7', '#22c55e', '#f97316', '#f43f5e', '#eab308', '#06b6d4', '#ec4899'];
    const maxImp = Math.max(...kws.map(k => k.importance), 1);
    const placed = [];

    kws.forEach((kw, i) => {
      const fs = 14 + (kw.importance / maxImp) * 28;
      const el = document.createElement('span');
      el.className = 'cloud-word';
      el.textContent = kw.word;
      el.style.cssText = `font-size:${fs}px;color:${palette[i % palette.length]};opacity:${.45 + (kw.importance / maxImp) * .55};text-shadow:0 0 ${kw.importance * 4}px ${palette[i % palette.length]}60`;
      const pos = this.place(W, H, fs, kw.word.length, placed, i);
      el.style.left = pos.x + 'px'; el.style.top = pos.y + 'px';
      placed.push({ ...pos, w: kw.word.length * fs * 0.55 + 8, h: fs + 4 });
      el.addEventListener('click', e => this.showTip(kw, e.clientX, e.clientY));
      el.addEventListener('mouseleave', () => document.getElementById('cloudTip')?.classList.add('hidden'));
      wrap.appendChild(el);
    });
  },
  place(W, H, fs, len, placed, idx) {
    const ww = len * fs * 0.55 + 8, wh = fs + 4;
    for (let t = 0; t < 80; t++) {
      const x = Math.random() * (W - ww - 8) + 4, y = Math.random() * (H - wh - 8) + 4;
      if (!placed.some(p => x < p.x + p.w && x + ww > p.x && y < p.y + p.h && y + wh > p.y)) return { x, y };
    }
    return { x: (idx % 5) * 120 + 10, y: Math.floor(idx / 5) * 60 + 10 };
  },
  showTip(kw, mx, my) {
    const tip = document.getElementById('cloudTip');
    if (!tip) return;
    tip.innerHTML = `<strong>${kw.word}</strong><br><span style="color:var(--text-3)">${kw.description || ''}</span>`;
    tip.style.left = (mx + 12) + 'px'; tip.style.top = (my - 20) + 'px';
    tip.classList.remove('hidden');
  }
};
