// statistics.js — 학습 통계
const Stats = {
  refresh() {
    const histAll = S.history();
    const studyMin = S.studyMin();
    const cards = document.getElementById('statCards');
    if (cards) {
      cards.innerHTML = `
        <div class="stat-card"><div class="stat-n">${histAll.length}</div><div class="stat-l">총 분석 횟수</div></div>
        <div class="stat-card"><div class="stat-n">${S.avgScore()}%</div><div class="stat-l">평균 점수</div></div>
        <div class="stat-card"><div class="stat-n">${studyMin >= 60 ? Math.floor(studyMin/60)+'시간 '+(studyMin%60)+'분' : studyMin+'분'}</div><div class="stat-l">총 공부 시간</div></div>
        <div class="stat-card"><div class="stat-n">${S.pomodoro()}</div><div class="stat-l">포모도로 완료</div></div>
      `;
    }
    Graph.renderWeekly();
  }
};
