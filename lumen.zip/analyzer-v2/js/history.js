// history.js — 분석 기록 저장/검색/즐겨찾기
const History = {
  MAX: 100,

  init() {
    this.render();
    document.getElementById('histSearch')?.addEventListener('input', e => this.render(e.target.value.trim()));
    document.getElementById('histClearBtn')?.addEventListener('click', () => {
      if (confirm('모든 분석 기록을 삭제할까요?')) { S.saveHistory([]); this.render(); App.toast('기록 삭제됨', 'ok'); }
    });
  },

  add(result, text, grade) {
    if (!result) return;
    const all = S.history();
    all.unshift({
      id: Date.now(),
      date: new Date().toLocaleString('ko-KR'),
      ts: Date.now(),
      language: result.language || 'ko',
      mainTopic: result.mainTopic || '',
      summary: result.summary || '',
      grade: grade || '',
      preview: text.substring(0, 120),
      result,
      starred: false
    });
    if (all.length > this.MAX) all.pop();
    S.saveHistory(all);
    this.render();
  },

  render(q = '') {
    const list = document.getElementById('histList');
    if (!list) return;
    let entries = S.history();
    if (q) { const ql = q.toLowerCase(); entries = entries.filter(e => e.mainTopic?.toLowerCase().includes(ql) || e.preview?.toLowerCase().includes(ql)); }

    if (!entries.length) {
      list.innerHTML = `<div class="ph"><div class="ph-icon">⧉</div><p>${q ? '검색 결과가 없습니다.' : '아직 분석 기록이 없습니다.'}</p></div>`;
      return;
    }

    list.innerHTML = `<div class="hist-list">` + entries.map(e => `
      <div class="hist-item">
        <div class="hist-text" onclick="History.open(${e.id})">
          <div class="hist-title">${e.mainTopic || e.preview?.slice(0,40) || '(제목 없음)'}</div>
          <div class="hist-meta"><span class="hist-badge ${e.language}">${e.language === 'ko' ? '국어' : '영어'}</span> ${e.grade || ''} · ${e.date}</div>
        </div>
        <div class="hist-actions">
          <button class="hist-star ${e.starred ? 'on' : ''}" onclick="History.star(${e.id})">★</button>
          <button class="hist-del" onclick="History.del(${e.id})">✕</button>
        </div>
      </div>`).join('') + `</div>`;
  },

  open(id) {
    const e = S.history().find(x => x.id === id);
    if (!e) return;
    const modal = document.getElementById('histModal'), body = document.getElementById('histModalBody');
    body.innerHTML = `
      <div style="margin-bottom:1rem"><span class="hist-badge ${e.language}">${e.language === 'ko' ? '국어' : '영어'}</span> <span style="font-size:.78rem;color:var(--text-3);margin-left:.5rem">${e.date}</span></div>
      <h3 style="margin-bottom:.5rem;font-family:'Syne',sans-serif">${e.mainTopic || ''}</h3>
      <p style="font-size:.86rem;color:var(--text-2);margin-bottom:1rem;line-height:1.7">${e.summary || ''}</p>
      <p style="font-size:.82rem;line-height:1.7;background:var(--bg-2);padding:.85rem;border-radius:8px;color:var(--text-2)">${e.preview}...</p>
      <button class="cta-btn" style="margin-top:1rem" onclick="History.load(${e.id})">이 분석 불러오기</button>
    `;
    modal.classList.remove('hidden');
  },

  load(id) {
    const e = S.history().find(x => x.id === id);
    if (!e) return;
    currentResult = e.result;
    document.getElementById('hero')?.classList.add('hidden');
    document.getElementById('resultArea')?.classList.remove('hidden');
    Analysis.render(e.result);
    Mindmap.render(e.result);
    Graph.render(e.result);
    WordCloud.render(e.result);
    Questions.render(e.result);
    Planner.render(e.result);
    document.getElementById('histModal')?.classList.add('hidden');
    document.querySelector('[data-tab="summary"]')?.click();
    App.toast('분석을 불러왔습니다.', 'ok');
  },

  star(id) { const all = S.history(); const e = all.find(x => x.id === id); if (e) { e.starred = !e.starred; S.saveHistory(all); this.render(); } },
  del(id)  { S.saveHistory(S.history().filter(x => x.id !== id)); this.render(); }
};
