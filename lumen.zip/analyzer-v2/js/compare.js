// compare.js — 두 지문 비교 분석 (Claude API)
const Compare = {
  async run() {
    const t1 = document.getElementById('inputText').value.trim();
    const t2 = document.getElementById('compareText').value.trim();
    if (!t1 || !t2) return App.toast('두 지문을 모두 입력해주세요.', 'err');

    App.showLoading();
    document.getElementById('loadingText').textContent = '두 지문을 비교 분석 중...';

    try {
      const prompt = `다음 두 지문을 분석하고 비교하여 순수 JSON만 반환하세요.

지문1:
"""${t1}"""

지문2:
"""${t2}"""

JSON 구조:
{
  "text1": {"summary":"요약","mainTopic":"중심내용","keywords":["키워드1","키워드2","키워드3"],"tone":"어조"},
  "text2": {"summary":"요약","mainTopic":"중심내용","keywords":["키워드1","키워드2","키워드3"],"tone":"어조"},
  "commonalities": ["공통점1","공통점2","공통점3"],
  "differences": [{"aspect":"주제","text1":"설명","text2":"설명"},{"aspect":"어조","text1":"설명","text2":"설명"},{"aspect":"구조","text1":"설명","text2":"설명"}],
  "commonKeywords": ["공통키워드1","공통키워드2"],
  "uniqueKeywords1": ["고유1","고유2"],
  "uniqueKeywords2": ["고유1","고유2"],
  "conclusion": "종합 결론"
}`;

      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 2000, messages: [{ role: 'user', content: prompt }] })
      });
      if (!res.ok) throw new Error('API 오류');
      const data = await res.json();
      const raw = data.content?.map(b => b.text || '').join('') || '';
      const result = Analysis.parse(raw);

      App.hideLoading();
      this.render(result);
      document.querySelector('[data-tab="compare"]')?.click();
      App.toast('비교 분석 완료!', 'ok');
    } catch (e) {
      App.hideLoading();
      App.toast('비교 실패: ' + e.message, 'err');
    }
  },

  render(r) {
    const c = document.getElementById('compareResult');
    if (!c) return;
    const kw = arr => (arr || []).map(k => `<span class="kw-tag kw-b" style="margin:2px">${k}</span>`).join('');

    c.innerHTML = `
      <div class="cmp-grid">
        <div class="cmp-card"><h3>지문 1</h3>
          <p style="font-size:.84rem;color:var(--text-3);margin-bottom:.5rem">${r.text1?.mainTopic || ''}</p>
          <p style="font-size:.82rem;line-height:1.75;color:var(--text-2)">${r.text1?.summary || ''}</p>
          <div style="margin-top:.75rem">${kw(r.text1?.keywords)}</div>
          <div style="margin-top:.5rem;font-size:.76rem;color:var(--text-3)">어조: ${r.text1?.tone || ''}</div>
        </div>
        <div class="cmp-card"><h3>지문 2</h3>
          <p style="font-size:.84rem;color:var(--text-3);margin-bottom:.5rem">${r.text2?.mainTopic || ''}</p>
          <p style="font-size:.82rem;line-height:1.75;color:var(--text-2)">${r.text2?.summary || ''}</p>
          <div style="margin-top:.75rem">${kw(r.text2?.keywords)}</div>
          <div style="margin-top:.5rem;font-size:.76rem;color:var(--text-3)">어조: ${r.text2?.tone || ''}</div>
        </div>
      </div>

      <div class="cmp-card" style="margin-top:1rem">
        <h3>공통점</h3>
        <ul style="padding-left:1.2rem;font-size:.86rem;line-height:2;color:var(--text-2)">${(r.commonalities||[]).map(c=>`<li>${c}</li>`).join('')}</ul>
        <div style="margin-top:.6rem"><div style="font-size:.72rem;color:var(--text-3);margin-bottom:.4rem">공통 키워드</div>${kw(r.commonKeywords)}</div>
      </div>

      <table class="cmp-table" style="margin-top:1rem">
        <thead><tr><th>비교 항목</th><th>지문 1</th><th>지문 2</th></tr></thead>
        <tbody>${(r.differences||[]).map(d=>`<tr><td><strong>${d.aspect}</strong></td><td>${d.text1}</td><td>${d.text2}</td></tr>`).join('')}</tbody>
      </table>

      <div class="cmp-grid" style="margin-top:1rem">
        <div class="cmp-card"><h3>지문1 고유 키워드</h3>${kw(r.uniqueKeywords1)}</div>
        <div class="cmp-card"><h3>지문2 고유 키워드</h3>${kw(r.uniqueKeywords2)}</div>
      </div>

      <div class="cmp-card" style="margin-top:1rem"><h3>종합 결론</h3><p style="font-size:.86rem;line-height:1.85;color:var(--text-2)">${r.conclusion || ''}</p></div>
    `;
  }
};
