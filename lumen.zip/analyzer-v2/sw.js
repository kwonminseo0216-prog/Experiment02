// sw.js — PWA offline support
const CACHE = 'lumen-v1';
const ASSETS = [
  '/', '/index.html', '/style.css',
  '/js/storage.js','/js/app.js','/js/upload.js','/js/ocr.js','/js/tts.js',
  '/js/analysis.js','/js/mindmap.js','/js/graph.js','/js/wordcloud.js',
  '/js/highlight.js','/js/question.js','/js/grading.js','/js/export.js',
  '/js/history.js','/js/compare.js','/js/timer.js','/js/statistics.js',
  '/js/aiTeacher.js','/js/studyPlanner.js','/js/account.js'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).catch(() => {}));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  if (e.request.url.includes('api.anthropic.com')) return;
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(res => {
      if (res.ok) { const clone = res.clone(); caches.open(CACHE).then(c => c.put(e.request, clone)); }
      return res;
    }).catch(() => { if (e.request.headers.get('accept')?.includes('text/html')) return caches.match('/index.html'); }))
  );
});
